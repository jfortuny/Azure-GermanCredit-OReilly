# R Code for Exploration and Analysis of UCI German Credit Data using Azure Machine Learning and R

This repository contains the R code for the exploration and analysis of the [UCI German Credit data](https://archive.ics.uci.edu/ml/datasets/Statlog+%28German+Credit+Data%29) with [Microsoft Azure Machine Learning](https://archive.ics.uci.edu/ml/datasets/Bike+Sharing+Dataset) and R.    